
function calculate(){
var x = document.getElementById("n1").value;
var y = document.getElementById("n2").value;
if (document.getElementById("op").value === "+"){
  alert(x*1 + y*1);
}
if (document.getElementById("op").value === "-"){
  alert(x-y);
}
if (document.getElementById("op").value === "*"){
  alert(x*y);
}
if (document.getElementById("op").value === "/"){
  alert(x/y);
}
}
